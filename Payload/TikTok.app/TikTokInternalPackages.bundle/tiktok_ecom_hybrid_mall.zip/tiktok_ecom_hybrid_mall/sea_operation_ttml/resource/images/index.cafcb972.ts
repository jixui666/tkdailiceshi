import { LiveChannelLive, LiveChannelStyleConfig } from '@components/channels/live_channel/interface';

Component({
  data: {},
  properties: {
    live: {
      type: Object,
      value: {} as LiveChannelLive,
      observer(newVal, oldVal) {
        console.log('live change: ', {newVal, oldVal})
      },
    },
    style_config: {
      type: Object,
      value: {} as LiveChannelStyleConfig,
      observer(newVal, oldVal) {},
    },
    isFallback: {
      type: Boolean,
      value: false,
      observer(newVal, oldVal) {}
    }
  },
  methods: {},

  created() {},
  attached() {},
  ready() {},
  detached() {},
});